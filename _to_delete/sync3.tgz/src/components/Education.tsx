import { useEffect, useState } from 'react'
import Reveal from './Reveal'
import Tags from './Tags'
import { useInView } from '../hooks/useInView'
import { advancedCoursework, coursework, electives } from '../data'

const START = new Date(2024, 7, 26).getTime()
const END = new Date(2028, 4, 15).getTime()

export default function Education() {
  const pct = Math.max(0, Math.min(1, (Date.now() - START) / (END - START))) * 100
  const [ref, seen] = useInView<HTMLDivElement>(0.4)
  const [w, setW] = useState(0)
  useEffect(() => { if (seen) setW(pct) }, [seen, pct])

  return (
    <section id="education" className="section">
      <div className="wrap">
        <Reveal as="h2" className="sec-title"><span>05</span> Education</Reveal>
        <div className="edu-grid">
          {/* ---------- Stony Brook ---------- */}
          <Reveal as="article" className="edu">
            <div className="edu-top">
              <img className="school-logo" src={`${import.meta.env.BASE_URL}sbu-logo.png`} alt="Stony Brook University seal" width={80} height={80} />
              <div>
                <h3>Stony Brook University</h3>
                <p className="meta">B.S. in Computer Science · Stony Brook, NY</p>
              </div>
              <div className="edu-badges">
                <span className="edu-pill live">In progress</span>
                <span className="edu-pill">Aug 2024 – Present</span>
              </div>
            </div>
            <div className="edu-body">
              <div className="edu-stats">
                <div className="gpa-ring" style={{ ['--p' as string]: 98.5 }}><b>3.94</b><small>/ 4.00</small></div>
                <div className="edu-stat-text" ref={ref}>
                  <p><strong>Expected graduation</strong></p>
                  <p className="edu-big">May 2028</p>
                  <p className="meta">{Math.round(pct)}% of the way there</p>
                  <div className="bar"><i style={{ width: `${w}%` }} /></div>
                </div>
              </div>
              <div className="edu-courses">
                <h4>Related coursework</h4>
                <Tags tags={coursework} />
              </div>
            </div>
          </Reveal>

          {/* ---------- Francis Lewis ---------- */}
          <Reveal as="article" className="edu hs" delay={1}>
            <div className="edu-top">
              <img className="school-logo" src={`${import.meta.env.BASE_URL}flhs-logo.png`} alt="Francis Lewis High School seal" width={80} height={80} />
              <div>
                <h3>Francis Lewis High School</h3>
                <p className="meta">High School Diploma</p>
              </div>
              <div className="edu-badges">
                <span className="edu-pill done">Graduated</span>
                <span className="edu-pill">Sep 2020 – Jun 2024</span>
              </div>
            </div>
            <div className="edu-body">
              <div className="edu-stats">
                <div className="gpa-ring" style={{ ['--p' as string]: 100 }}><b style={{ fontSize: '1.05rem' }}>101.23%</b><small>Grade</small></div>
                <div className="edu-stat-text">
                  <p><strong>Graduated</strong></p>
                  <p className="edu-big">June 2024</p>
                  <p className="meta">9 advanced placement courses</p>
                  <div className="bar"><i style={{ width: '100%' }} /></div>
                </div>
              </div>
              <div className="edu-courses">
                <h4>Advanced coursework (9)</h4>
                <Tags tags={advancedCoursework} />
                <h4>Elective coursework</h4>
                <Tags tags={electives} />
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
