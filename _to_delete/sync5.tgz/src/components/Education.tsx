import { useEffect, useState } from 'react'
import Reveal from './Reveal'
import Tags from './Tags'
import { useInView } from '../hooks/useInView'
import { advancedCoursework, coursework, electives } from '../data'

const START = new Date(2024, 7, 26).getTime()
const END = new Date(2028, 4, 15).getTime()

export default function Education() {
  const pct = Math.max(0, Math.min(1, (Date.now() - START) / (END - START))) * 100
  const [ref, seen] = useInView<HTMLDivElement>(0.4)
  const [w, setW] = useState(0)
  useEffect(() => { if (seen) setW(pct) }, [seen, pct])

  return (
    <section id="education" className="section">
      <div className="wrap">
        <Reveal as="h2" className="sec-title"><span>05</span> Education</Reveal>
        <div className="edu-grid">
          <Reveal as="article" className="edu">
            <div className="edu-head">
              <img className="school-logo" src={`${import.meta.env.BASE_URL}sbu-logo.png`} alt="Stony Brook University seal" width={80} height={80} />
              <div>
                <h3>Stony Brook University</h3>
                <p className="meta">B.S. in Computer Science · Aug 2024 – Present · Stony Brook, NY</p>
              </div>
            </div>
            <div className="gpa">
              <div className="gpa-ring" style={{ ['--p' as string]: 98.5 }}><b>3.94</b><small>/ 4.00</small></div>
              <div ref={ref}>
                <p><strong>Expected graduation:</strong> May 2028</p>
                <p className="meta">Progress: {Math.round(pct)}% of the way to graduation</p>
                <div className="bar"><i style={{ width: `${w}%` }} /></div>
              </div>
            </div>
            <h4>Related coursework</h4>
            <Tags tags={coursework} />
          </Reveal>
          <Reveal as="article" className="edu hs" delay={1}>
            <div className="edu-head">
              <img className="school-logo" src={`${import.meta.env.BASE_URL}flhs-logo.png`} alt="Francis Lewis High School seal" width={80} height={80} />
              <div>
                <h3>Francis Lewis High School</h3>
                <p className="meta">High School Diploma · Sep 2020 – Jun 2024</p>
              </div>
            </div>
            <div className="gpa">
              <div className="gpa-ring" style={{ ['--p' as string]: 100 }}><b style={{ fontSize: '1.05rem' }}>101.23%</b><small>Grade</small></div>
              <div>
                <p><strong>Graduated:</strong> June 2024</p>
                <p className="meta">High School Diploma · 9 advanced courses</p>
              </div>
            </div>
            <h4>Advanced coursework (9)</h4>
            <Tags tags={advancedCoursework} />
            <h4>Elective coursework</h4>
            <Tags tags={electives} />
          </Reveal>
        </div>
      </div>
    </section>
  )
}
